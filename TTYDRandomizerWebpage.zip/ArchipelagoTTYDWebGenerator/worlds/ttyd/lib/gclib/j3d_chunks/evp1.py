
from gclib import fs_helpers as fs
from gclib.fs_helpers import u32, u24, u16, u8, s32, s16, s8, u16Rot, FixedStr, MagicStr
from gclib.jchunk import JChunk
from gclib.bunfoe import bunfoe, field, BUNFOE

class EVP1(JChunk):
  pass
