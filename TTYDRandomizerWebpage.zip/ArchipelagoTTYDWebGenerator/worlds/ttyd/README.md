# ArchipelagoTTYD

Important information about the randomizer can be found [here](https://github.com/jamesbrq/ArchipelagoTTYD/blob/main/docs/en_Paper%20Mario%20The%20Thousand-Year%20Door.md)

Mod is hosted seperately over at https://github.com/jamesbrq/TTYDAP
